---
title: "Software & Data"
permalink: /software/
---

## Code

- GitHub: (add your repositories here)

## Datasets

- (Add dataset descriptions, access notes, and links)

## Reproducibility

- Training configs
- Evaluation scripts
- Model cards (in progress)
