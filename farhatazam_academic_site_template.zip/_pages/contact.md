---
title: "Contact"
permalink: /contact/
---

Email: **farhatb14@gmail.com**

- Google Scholar: (link)
- LinkedIn: (link)
- GitHub: (link)
