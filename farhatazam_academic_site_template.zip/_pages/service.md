---
title: "Service & Talks"
permalink: /service/
---

## Service

- Reviewer / committee roles
- Community contributions

## Talks & Presentations

- Invited talks
- Conference presentations
