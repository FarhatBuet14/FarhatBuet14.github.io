---
title: "About"
permalink: /about/
---

I’m **Farhat Binte Azam**, a Postdoctoral Scholar at the University of South Florida. I build deployable computer vision and edge-to-cloud AI systems for public-health sensing, with a focus on mosquito surveillance, explainable AI, and field-ready deployment.
