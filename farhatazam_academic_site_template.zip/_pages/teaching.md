---
title: "Teaching & Mentoring"
permalink: /teaching/
---

## Teaching

- (Add courses, guest lectures, or TA roles)

## Mentoring

- (Add students mentored, project supervision, etc.)
