---
title: "CV"
permalink: /cv/
---

- [Download CV (PDF)](/assets/pdf/CV_Farhat_Binte_Azam.pdf)
